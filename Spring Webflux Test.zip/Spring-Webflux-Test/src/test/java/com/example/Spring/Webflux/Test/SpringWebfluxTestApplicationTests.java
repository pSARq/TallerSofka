package com.example.Spring.Webflux.Test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebfluxTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
